from GameStatus_5120 import GameStatus


def minimax(game_state: GameStatus, depth: int, maximizingPlayer: bool,
            alpha=float('-inf'), beta=float('inf')):
    terminal = game_state.is_terminal()
    if depth == 0 or terminal:
        newScores = game_state.get_scores(terminal)
        return newScores, None

    legal_moves = game_state.get_moves()
    if not legal_moves:
        return game_state.get_scores(terminal), None

    best_move = legal_moves[0]

    if maximizingPlayer:
        value = float('-inf')
        for move in legal_moves:
            child_state = game_state.get_new_state(move)
            child_value, _ = minimax(child_state, depth - 1, False, alpha, beta)
            if child_value > value:
                value = child_value
                best_move = move
            alpha = max(alpha, value)
            if beta <= alpha:
                break
        return value, best_move

    value = float('inf')
    for move in legal_moves:
        child_state = game_state.get_new_state(move)
        child_value, _ = minimax(child_state, depth - 1, True, alpha, beta)
        if child_value < value:
            value = child_value
            best_move = move
        beta = min(beta, value)
        if beta <= alpha:
            break
    return value, best_move


def negamax(game_status: GameStatus, depth: int, turn_multiplier: int,
            alpha=float('-inf'), beta=float('inf')):
    terminal = game_status.is_terminal()
    if depth == 0 or terminal:
        scores = game_status.get_negamax_scores(terminal)
        return turn_multiplier * scores, None

    legal_moves = game_status.get_moves()
    if not legal_moves:
        return turn_multiplier * game_status.get_negamax_scores(terminal), None

    value = float('-inf')
    best_move = legal_moves[0]

    for move in legal_moves:
        child_state = game_status.get_new_state(move)
        child_value, _ = negamax(child_state, depth - 1, -turn_multiplier, -beta, -alpha)
        child_value = -child_value

        if child_value > value:
            value = child_value
            best_move = move

        alpha = max(alpha, value)
        if alpha >= beta:
            break

    return value, best_move
