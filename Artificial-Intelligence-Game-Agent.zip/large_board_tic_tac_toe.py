"""
Minimal but complete pygame GUI for the homework.
Controls:
- Left click: place X
- R: reset board
- M: use Minimax
- N: use Negamax
- 3..7: board size
- H: toggle human-vs-human / human-vs-AI
- Up/Down: change search depth
"""
import sys
import pygame
import numpy as np
from GameStatus_5120 import GameStatus
from multiAgents import minimax, negamax

mode = "player_vs_ai"


class RandomBoardTicTacToe:
    def __init__(self, size=(700, 820)):
        self.size = self.width, self.height = size
        self.TOP_PANEL = 120

        self.BLACK = (18, 18, 18)
        self.WHITE = (240, 240, 240)
        self.GREEN = (60, 180, 120)
        self.RED = (220, 80, 80)
        self.GRAY = (120, 120, 120)
        self.BLUE = (80, 140, 240)

        self.GRID_SIZE = 4
        self.OFFSET = 5
        self.MARGIN = 5
        self.board_pixels = min(self.width, self.height - self.TOP_PANEL)
        self.cell_size = self.board_pixels / self.GRID_SIZE

        self.CIRCLE_COLOR = (140, 146, 172)
        self.CROSS_COLOR = (220, 220, 220)
        self.algorithm = "minimax"
        self.search_depth = 3
        self.game_mode = mode
        self.game_over = False
        self.status_text = "Click a cell to start"

        pygame.init()
        self.font = pygame.font.SysFont("arial", 22)
        self.small_font = pygame.font.SysFont("arial", 18)
        self.game_reset()

    def _recompute_geometry(self):
        self.cell_size = self.board_pixels / self.GRID_SIZE

    def draw_game(self):
        pygame.init()
        self.screen = pygame.display.set_mode(self.size)
        self.screen.fill(self.BLACK)

        title = self.font.render("CSE 5120 - Multiagent Tic-Tac-Toe", True, self.WHITE)
        info1 = self.small_font.render(
            f"Algorithm: {self.algorithm} | Mode: {self.game_mode} | Depth: {self.search_depth}",
            True,
            self.WHITE,
        )
        info2 = self.small_font.render(
            "Controls: click=move, R=reset, M=minimax, N=negamax, H=toggle mode, 3-7=size, Up/Down=depth",
            True,
            self.GRAY,
        )
        status = self.small_font.render(self.status_text, True, self.GREEN if not self.game_over else self.RED)

        self.screen.blit(title, (15, 12))
        self.screen.blit(info1, (15, 45))
        self.screen.blit(info2, (15, 70))
        self.screen.blit(status, (15, 95))

        for r in range(self.GRID_SIZE):
            for c in range(self.GRID_SIZE):
                rect = pygame.Rect(
                    int(c * self.cell_size) + self.MARGIN,
                    self.TOP_PANEL + int(r * self.cell_size) + self.MARGIN,
                    int(self.cell_size) - self.MARGIN,
                    int(self.cell_size) - self.MARGIN,
                )
                pygame.draw.rect(self.screen, self.WHITE, rect, width=1)

        for r in range(self.GRID_SIZE):
            for c in range(self.GRID_SIZE):
                value = self.game_state.board_state[r, c]
                if value == -1:
                    self.draw_cross(r, c)
                elif value == 1:
                    self.draw_circle(r, c)

        pygame.display.update()

    def change_turn(self):
        if self.game_state.turn_O:
            pygame.display.set_caption("Tic Tac Toe - O's turn")
        else:
            pygame.display.set_caption("Tic Tac Toe - X's turn")

    def _cell_center(self, x, y):
        left = int(y * self.cell_size)
        top = self.TOP_PANEL + int(x * self.cell_size)
        center_x = left + int(self.cell_size / 2)
        center_y = top + int(self.cell_size / 2)
        return center_x, center_y, left, top

    def draw_circle(self, x, y):
        center_x, center_y, _, _ = self._cell_center(x, y)
        radius = max(12, int(self.cell_size * 0.28))
        pygame.draw.circle(self.screen, self.CIRCLE_COLOR, (center_x, center_y), radius, width=4)

    def draw_cross(self, x, y):
        _, _, left, top = self._cell_center(x, y)
        padding = int(self.cell_size * 0.22)
        start1 = (left + padding, top + padding)
        end1 = (left + int(self.cell_size) - padding, top + int(self.cell_size) - padding)
        start2 = (left + int(self.cell_size) - padding, top + padding)
        end2 = (left + padding, top + int(self.cell_size) - padding)
        pygame.draw.line(self.screen, self.CROSS_COLOR, start1, end1, width=4)
        pygame.draw.line(self.screen, self.CROSS_COLOR, start2, end2, width=4)

    def is_game_over(self):
        return self.game_state.is_terminal()

    def move(self, move):
        self.game_state = self.game_state.get_new_state(move)
        self.change_turn()

    def _update_status_from_score(self):
        terminal = self.game_state.is_terminal()
        score = self.game_state.get_scores(terminal)
        if terminal:
            if score > 0:
                self.status_text = f"Game Over - X wins | score={score}"
            elif score < 0:
                self.status_text = f"Game Over - O wins | score={score}"
            else:
                self.status_text = f"Game Over - Draw | score={score}"
            self.game_over = True
        else:
            self.status_text = f"Current heuristic score: {score}"
            self.game_over = False

    def play_ai(self):
        if self.is_game_over():
            self._update_status_from_score()
            self.draw_game()
            return

        if self.algorithm == "negamax":
            score, move = negamax(self.game_state, self.search_depth, -1)
        else:
            score, move = minimax(self.game_state, self.search_depth, False)

        if move is not None:
            self.move(move)
            self.status_text = f"AI played {move} using {self.algorithm} | value={score}"

        self._update_status_from_score()
        self.draw_game()

    def game_reset(self):
        self._recompute_geometry()
        board = np.zeros((self.GRID_SIZE, self.GRID_SIZE), dtype=int)
        self.game_state = GameStatus(board, False)
        self.game_over = False
        self.status_text = "New game - X moves first"
        self.draw_game()
        self.change_turn()

    def _handle_human_click(self, pos):
        if self.game_over:
            return

        x_pix, y_pix = pos
        if y_pix < self.TOP_PANEL:
            return

        row = int((y_pix - self.TOP_PANEL) / self.cell_size)
        col = int(x_pix / self.cell_size)

        if row < 0 or row >= self.GRID_SIZE or col < 0 or col >= self.GRID_SIZE:
            return

        if self.game_state.board_state[row, col] != 0:
            self.status_text = "Cell already occupied"
            self.draw_game()
            return

        self.move((row, col))
        self._update_status_from_score()
        self.draw_game()

        if not self.game_over and self.game_mode == "player_vs_ai":
            self.play_ai()

    def play_game(self, mode="player_vs_ai"):
        self.game_mode = mode
        done = False
        clock = pygame.time.Clock()

        while not done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    done = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.game_reset()
                    elif event.key == pygame.K_m:
                        self.algorithm = "minimax"
                        self.status_text = "Switched to minimax"
                        self.draw_game()
                    elif event.key == pygame.K_n:
                        self.algorithm = "negamax"
                        self.status_text = "Switched to negamax"
                        self.draw_game()
                    elif event.key == pygame.K_h:
                        self.game_mode = "player_vs_player" if self.game_mode == "player_vs_ai" else "player_vs_ai"
                        self.status_text = f"Mode changed to {self.game_mode}"
                        self.draw_game()
                    elif event.key in (pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7):
                        self.GRID_SIZE = int(event.unicode)
                        self.game_reset()
                    elif event.key == pygame.K_UP:
                        self.search_depth += 1
                        self.status_text = f"Depth changed to {self.search_depth}"
                        self.draw_game()
                    elif event.key == pygame.K_DOWN:
                        self.search_depth = max(1, self.search_depth - 1)
                        self.status_text = f"Depth changed to {self.search_depth}"
                        self.draw_game()
                elif event.type == pygame.MOUSEBUTTONUP:
                    self._handle_human_click(event.pos)

                    if self.game_mode == "player_vs_player" and not self.game_over:
                        self._update_status_from_score()
                        self.draw_game()

            pygame.display.update()
            clock.tick(30)

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    tictactoegame = RandomBoardTicTacToe()
    tictactoegame.play_game(mode)
