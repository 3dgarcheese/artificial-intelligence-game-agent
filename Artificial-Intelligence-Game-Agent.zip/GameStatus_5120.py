# -*- coding: utf-8 -*-
import numpy as np


class GameStatus:
    def __init__(self, board_state, turn_O):
        self.board_state = board_state
        self.turn_O = turn_O
        self.oldScores = 0
        self.winner = ""

    def _iter_triplets(self):
        rows = len(self.board_state)
        cols = len(self.board_state[0])

        # Horizontal
        for r in range(rows):
            for c in range(cols - 2):
                yield [self.board_state[r, c + i] for i in range(3)]

        # Vertical
        for r in range(rows - 2):
            for c in range(cols):
                yield [self.board_state[r + i, c] for i in range(3)]

        # Main diagonal
        for r in range(rows - 2):
            for c in range(cols - 2):
                yield [self.board_state[r + i, c + i] for i in range(3)]

        # Anti-diagonal
        for r in range(rows - 2):
            for c in range(2, cols):
                yield [self.board_state[r + i, c - i] for i in range(3)]

    def is_terminal(self):
        """
        Terminal when there are no empty cells left.
        Also stores the winner string based on the final score.
        """
        if np.any(self.board_state == 0):
            self.winner = ""
            return False

        final_score = self.get_scores(True)
        if final_score > 0:
            self.winner = "X"
        elif final_score < 0:
            self.winner = "O"
        else:
            self.winner = "Draw"
        return True

    def get_scores(self, terminal):
        """
        Positive score favors the human player (X = -1 by default).
        Negative score favors the AI player (O = +1 by default).

        For terminal boards, count completed triplets.
        For non-terminal boards, use a light heuristic:
        - completed triplet: +/- 100
        - open two-in-a-row: +/- 10
        - single mark in an otherwise empty triplet: +/- 1
        """
        score = 0

        for triplet in self._iter_triplets():
            human_count = triplet.count(-1)
            ai_count = triplet.count(1)
            empty_count = triplet.count(0)

            if human_count and ai_count:
                continue

            if terminal:
                if human_count == 3:
                    score += 1
                elif ai_count == 3:
                    score -= 1
                continue

            if human_count == 3:
                score += 100
            elif ai_count == 3:
                score -= 100
            elif human_count == 2 and empty_count == 1:
                score += 10
            elif ai_count == 2 and empty_count == 1:
                score -= 10
            elif human_count == 1 and empty_count == 2:
                score += 1
            elif ai_count == 1 and empty_count == 2:
                score -= 1

        return score

    def get_negamax_scores(self, terminal):
        return self.get_scores(terminal)

    def get_moves(self):
        moves = []
        rows = len(self.board_state)
        cols = len(self.board_state[0])
        for r in range(rows):
            for c in range(cols):
                if self.board_state[r, c] == 0:
                    moves.append((r, c))
        return moves

    def get_new_state(self, move):
        new_board_state = self.board_state.copy()
        x, y = move[0], move[1]
        new_board_state[x, y] = 1 if self.turn_O else -1
        return GameStatus(new_board_state, not self.turn_O)
